package model;

public enum TreeSize {
	S, 
	M, 
	L, 
	XL, 
	XXL

}
