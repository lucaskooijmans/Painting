package model;

public enum TreeType {
	PINE, 
	LEAF
}
